﻿
"""
简易图书馆资源管理系统
一、实验目标
1. 熟练运用 Python 的核心数据结构（列表、字典）进行数据存储与处理。
2. 掌握函数的定义与调用，理解代码模块化思想。
3. 理解面向对象编程（OOP）思想，能够设计并使用类封装数据与功能。
4. 培养问题分析、系统设计及代码实现能力。
二、基础功能要求（90 分）
设计一个“简易图书馆资源管理系统”，需综合运用列表、字典、函数和类，实
现以下功能：
1. 数据结构设计（10 分）
定义 Book 类，包含属性：
⯎
定义一个 Book 类，包含图书的核心属性：图书 ID（唯一标识）、书名、作
者、出版社、是否可借（布尔值）。
⯎
使用列表存储系统中所有图书（Book 类的实例）。
⯎
使用字典存储借阅记录，键为“图书 ID”，值为“借阅人姓名”。
2. 核心功能实现（共 80 分）
封装一个 Library 类，实现以下方法：
⯎
添加图书：接收用户输入的图书信息（ID、书名、作者等），创建 Book 实
例并添加到图书列表（需检查 ID 唯一性，避免重复）。
⯎
查询图书：支持两种查询方式（通过函数参数区分）：
■
按 “书名” 模糊查询（返回所有包含关键词的图书列表）；
■
按 “作者” 精确查询（返回该作者的所有图书列表）。
⯎
修改图书信息：根据图书 ID 查找图书，允许修改除 ID 外的其他属性（如
更新出版社）。
⯎
删除图书：根据图书 ID 删除图书（需先检查是否已被借阅，若已借阅则不
允许删除）。
⯎
借阅图书：接收图书 ID 和借阅人姓名，修改图书的 “可借状态” 为 False，
并记录到借阅字典中（需检查图书是否可借）。
⯎
归还图书：根据图书 ID，修改图书的 “可借状态” 为 True，并从借阅字
典中移除记录。
三、附加功能（10 分）
从以下方向选择 1-2 项实现，或自主设计其他合理功能：
⯎
数据持久化：将图书列表和借阅记录保存到本地文件（如txt、json），程序启动时自动加载。

高级查询：支持按 “出版社”“是否可借” 等条件组合查询，或按 “图书 ID”/“书名” 排序后展示。

借阅统计：新增属性记录每本书的借阅次数，或统计指定借阅人的历史借阅记录。

用户权限：区分 “管理员” 和 “普通用户” 角色（管理员可执行所有作，普通用户仅能查询和借阅）。

图形界面：使用 tkinter 库设计简单的可视化操作界面（如按钮、输入框）。

"""

import json
import os


class Book:
    """
    定义一个 Book 类，包含图书的核心属性：图书 ID（唯一标识）、书名、作者、出版社、是否可借（布尔值）。
    """

    #默认构造函数
    def __init__(self,book_id,title,author,publisher,is_available=True,borrow_count=0):
        self.book_id=str(book_id)
        self.title=title
        self.author=author
        self.publisher=publisher
        self.is_available=bool(is_available)
        self.borrow_count = int(borrow_count)

    #打印图书信息
    def print_book_info(self):
        print(f"图书ID：{self.book_id}")
        print(f"书名：《{self.title}》")
        print(f"作者：{self.author}")
        print(f"出版社：{self.publisher}")
        print(f"是否可借：{self.is_available}")
        print(f"借阅次数：{self.borrow_count}")


    def to_dict(self):
        return{
            "book_id":self.book_id,
            "title":self.title,
            "author":self.author,
            "publisher":self.publisher,
            "is_available":self.is_available,
            "borrow_count":self.borrow_count,
        }

    @staticmethod
    def from_dict(data:dict):
        return Book(
            book_id=data["book_id"],
            title=data["title"],
            author=data["author"],
            publisher=data["publisher"],
            is_available=data.get("is_available",True),
            borrow_count=data.get("borrow_count",0),
            )

        """
        #使用列表存储系统中所有图书（Book 类的实例）
        books = []

        #添加一本图书示例
        book1=Book("001","Python编程:从入门到实践","[美]埃里克·马瑟斯(Eric Matthes)","人民邮电出版社",True)
        books.append(book1)

        #使用字典存储借阅记录，键为“图书 ID”，值为“借阅人姓名”
        borrow_records={}

        #假设图书ID为"001"被"王五"借走
        borrow_records["001"]="王五"
        """

        


class Library:
    """
    封装一个 Library 类
    - self.books:列表，存储Book实例
    - self.borrow_records:字典，键为图书ID，值为借阅人姓名

    """
    def __init__(self,data_file:str|None=None):
        # 用于存储所有图书(Book实例)的列表
        self.books=[]
        # 用于存储借阅记录，键为图书ID，值为借阅人 user_name
        self.borrow_records={}
        self.data_file=data_file
        if self.data_file and os.path.exists(self.data_file):
            self.load_from_file(self.data_file)

    #工具方法：根据ID查找图书
    def find_book_by_id(self,book_id):
        for book in self.books:
            if book.book_id == str(book_id):
                return book
        return None

    def add_book(self,book_id,title,author,publisher,is_available=True):
        """
        添加图书：接收用户输入的图书信息（ID、书名、作者等），
        创建 Book 实例并添加到图书列表（需检查 ID 唯一性，避免重复）
        """
        # 检查ID唯一性
        if self.find_book_by_id(book_id) is not None:
            print(f"图书ID{book_id}已存在，不能重复添加！")
            return False

        #创建Book实例并添加
        new_book = Book(book_id,title,author,publisher,is_available)
        self.books.append(new_book)
        print(f"图书《{title}》已成功添加！")
        return True


    def search_book(self,value,mode="title"):
     """
     综合查询方法
     :param value: 查询关键词或作者名
     :param mode: 查询模式，"title"为书名模糊查询，"author"为作者精确查询
     :return: 匹配的图书列表
     """
     result = []
     if mode == "title":
         keyword = str(value).lower()
         for book in self.books:
             if keyword in book.title:
                 result.append(book)
     elif mode == "author":
         for book in self.books:
             if str(value) == book.author:
                 result.append(book)
     else:
         print("查询模式不正确，应为'title' 或 'author'")
     return result

    #高级查询功能
    def advanced_query(self,publisher=None,is_available=None,sort_by=None):
        result = self.books
        if publisher is not None:
            result = [b for b in result if b.publisher == publisher]
        if is_available is not None:
            result = [b for b in result if b.is_available == is_available]
        if sort_by =="book_id":
            result = sorted(result,ket=lambda b:b.book_id)
        elif sort_by == "title":
            result = sorted(result,key = lambda b:b.title)
        elif sort_by =="borrow_count":
            result = sorted(result,key = lambda b:b.borrow_count,reverse=True)
        return result

    def modify_book(self,book_id,title=None,author=None,publisher=None,is_available=None):
        """
        修改图书信息：根据图书 ID 查找图书，允许修改除 ID 外的其他属性
        : param book_id:        要修改的图书ID
        : param title:          新书名（可选）
        : param author:         新作者（可选）
        : param publisher:      新出版社（可选）
        : param is_available:   新可借情况（可选）
        """
        for book in self.books:
            if book.book_id == book_id:
                if title is not None:
                    book.title = title
                if author is not None:
                    book.author = author
                if publisher is not None:
                    book.publisher = publisher;
                if is_available is not None:
                    book.is_available = is_available
                print(f"图书ID{book_id}信息已更新")
                book.print_book_info()
                return True
        print(f"未找到图书ID{book_id}()，无法更新图书信息")
        return False

    def remove_book(self,book_id):
            """
            删除图书：根据图书 ID 删除图书
           （需先检查是否已被借阅，若已借阅则不允许删除）
            """
            for book in self.books:
                if book.book_id == book_id:
                    # 检查借阅记录
                    if book_id in self.borrow_records:
                        print(f"图书{book.title}正被借阅，无法删除")
                        return False
                    # 如果未被借阅，则可以删除
                    self.books.remove(book)
                    print(f"图书{book.title}已被删除")
                    return True
            print(f"未找到图书ID《{book_id}》")
            return False

    def borrow_book(self,book_id,user_name):
            """
            借阅图书：接收图书 ID 和借阅人姓名，修改图书的 “可借状态” 为 False，
            并记录到借阅字典中（需检查图书是否可借）。
            """
            for book in self.books:
                if book.book_id == book_id:
                    #检查借阅记录
                    if book_id in self.borrow_records:
                        print(f"图书《{book.title}》已被借阅")
                        return False
                    #如果可以此图书可被借阅
                    book.is_available = False
                    self.borrow_records[book_id] = user_name
                    book.borrow_count+=1
                    print(f"图书《{book.title}》已借给{user_name}")


    def return_book(self,book_id):
            """
            归还图书：根据图书 ID，修改图书的 “可借状态” 为 True，
            并从借阅字典中移除记录。
            """
            for book in self.books:
                #检查借阅记录
                if book_id == book.book_id:
                    if book_id in self.borrow_records:
                        book.is_available = True
                        del self.borrow_records[book_id]
                        print(f"图书《{book.title}》已归还")
                        return True
                    else:
                        print(f"图书《{book.title}》未被借出，无需归还")
                        return False

            print(f"未找到图书{book_id}，无法归还")
            return False

    # 存储借阅数据
    def save_to_file(self,path=None):
        file_path = path or self.data_file
        if not file_path:
            print("未指定保存文件路径。")
            return False
        data = {
            "books":[b.to_dict() for b in self.books],
            "borrow_records":self.borrow_records,
            }
        with open(file_path,"w",encoding="utf-8") as f:
            json.dump(data,f,ensure_ascii=False,indent=2)
        print(f"数据已保存到{file_path}")
        return True

   #加载借阅数据
    def load_from_file(self,path):
       with open(path,"r",encoding="utf-8") as f:
           data = json.load(f)
       self.books=[Book.from_dict(d) for d in data.get("books",[])]
       self.borrow_records=data.get("borrow_records",{})
       print(f"已从{path}加载数据：图书{len(self.books)}本，借阅记录{len(self.borrow_records)}条")



if __name__ == "__main__":
    # 创建图书馆对象
    lib = Library(data_file="library_data.json")

    # 添加一些书籍
    lib.add_book("001", "Python编程:从入门到实践", "[美]埃里克·马瑟斯(Eric Matthes)", "人民邮电出版社", True)
    lib.add_book("002", "流畅的Python", "Luciano Ramalho", "人民邮电出版社", True)
    lib.add_book("003", "Python核心编程", "Wesley J. Chun", "电子工业出版社", True)
    lib.add_book("004", "简明Python教程", "Swaroop C H", "机械工业出版社", True)
    lib.add_book("005", "Python数据科学手册", "Jake VanderPlas", "人民邮电出版社", True)

    print("\n【1】当前图书馆藏书：")
    for book in lib.books:
        book.print_book_info()
        print("-" * 30)

    # 查询功能：书名模糊查询
    print("\n【2】按书名模糊查询（关键词 'Python'）：")
    result = lib.search_book("Python", mode="title")
    for book in result:
        book.print_book_info()
        print("-" * 30)

    # 查询功能：作者精确查询
    print("\n【3】按作者精确查询（作者 'Luciano Ramalho'）：")
    result = lib.search_book("Luciano Ramalho", mode="author")
    for book in result:
        book.print_book_info()
        print("-" * 30)

    # 修改图书信息
    print("\n【4】修改图书信息（ID '003'，出版社改为 '人民邮电出版社'）：")
    lib.modify_book("003", publisher="人民邮电出版社")

    # 删除图书（未被借阅）
    print("\n【5】删除图书（ID '004'）：")
    lib.remove_book("004")

    # 借阅图书
    print("\n【6】借阅图书（ID '001'，借阅人 '王五'）：")
    lib.borrow_book("001", "王五")

    # 再次尝试借阅同一本书（应提示已被借阅）
    print("\n【7】再次尝试借阅同一本书（ID '001'）：")
    lib.borrow_book("001", "李四")

    # 归还图书
    print("\n【8】归还图书（ID '001'）：")
    lib.return_book("001")

    # 高级查询：按出版社筛选、按借阅次数排序
    print("\n【9】高级查询（出版社 '人民邮电出版社'，按借阅次数降序）：")
    adv_result = lib.advanced_query(publisher="人民邮电出版社", sort_by="borrow_count")
    for book in adv_result:
        book.print_book_info()
        print("-" * 30)

    # 数据持久化：保存到文件
    print("\n【10】保存数据到文件：")
    lib.save_to_file()

    # 加载数据
    print("\n【11】从文件加载数据：")
    lib.load_from_file("library_data.json")

    import tkinter as tk
from tkinter import messagebox, simpledialog

class LibraryGUI:
    def __init__(self, master, library):
        self.master = master
        self.library = library
        master.title("简易图书馆管理系统")

        # 添加图书
        tk.Label(master, text="添加图书").grid(row=0, column=0, columnspan=2, pady=5)
        tk.Label(master, text="ID").grid(row=1, column=0)
        tk.Label(master, text="书名").grid(row=2, column=0)
        tk.Label(master, text="作者").grid(row=3, column=0)
        tk.Label(master, text="出版社").grid(row=4, column=0)
        self.entry_id = tk.Entry(master)
        self.entry_title = tk.Entry(master)
        self.entry_author = tk.Entry(master)
        self.entry_publisher = tk.Entry(master)
        self.entry_id.grid(row=1, column=1)
        self.entry_title.grid(row=2, column=1)
        self.entry_author.grid(row=3, column=1)
        self.entry_publisher.grid(row=4, column=1)
        tk.Button(master, text="添加", command=self.add_book).grid(row=5, column=0, columnspan=2, pady=5)

        # 查询图书
        tk.Label(master, text="查询图书").grid(row=6, column=0, columnspan=2, pady=5)
        self.entry_search = tk.Entry(master)
        self.entry_search.grid(row=7, column=0)
        tk.Button(master, text="按书名查询", command=self.search_by_title).grid(row=7, column=1)
        tk.Button(master, text="按作者查询", command=self.search_by_author).grid(row=8, column=1)

        # 借阅/归还
        tk.Label(master, text="借阅/归还").grid(row=9, column=0, columnspan=2, pady=5)
        self.entry_borrow_id = tk.Entry(master)
        self.entry_borrow_id.grid(row=10, column=0)
        tk.Button(master, text="借阅", command=self.borrow_book).grid(row=10, column=1)
        tk.Button(master, text="归还", command=self.return_book).grid(row=11, column=1)

        # 显示所有图书
        tk.Button(master, text="显示所有图书", command=self.show_all_books).grid(row=12, column=0, columnspan=2, pady=5)

    def add_book(self):
        book_id = self.entry_id.get()
        title = self.entry_title.get()
        author = self.entry_author.get()
        publisher = self.entry_publisher.get()
        if not (book_id and title and author and publisher):
            messagebox.showwarning("提示", "请填写完整信息")
            return
        if self.library.add_book(book_id, title, author, publisher, True):
            messagebox.showinfo("成功", f"图书《{title}》已添加")
        else:
            messagebox.showerror("失败", f"图书ID {book_id} 已存在")

    def search_by_title(self):
        keyword = self.entry_search.get()
        result = self.library.search_book(keyword, mode="title")
        self.show_books(result, f"书名包含“{keyword}”的图书")

    def search_by_author(self):
        author = self.entry_search.get()
        result = self.library.search_book(author, mode="author")
        self.show_books(result, f"作者为“{author}”的图书")

    def borrow_book(self):
        book_id = self.entry_borrow_id.get()
        user_name = simpledialog.askstring("借阅人", "请输入借阅人姓名：")
        if not (book_id and user_name):
            messagebox.showwarning("提示", "请填写图书ID和借阅人姓名")
            return
        if self.library.borrow_book(book_id, user_name):
            messagebox.showinfo("成功", f"图书已借出给 {user_name}")
        else:
            messagebox.showerror("失败", "借阅失败，可能已被借出或ID不存在")

    def return_book(self):
        book_id = self.entry_borrow_id.get()
        if not book_id:
            messagebox.showwarning("提示", "请填写图书ID")
            return
        if self.library.return_book(book_id):
            messagebox.showinfo("成功", "归还成功")
        else:
            messagebox.showerror("失败", "归还失败，可能未被借出或ID不存在")

    def show_all_books(self):
        self.show_books(self.library.books, "所有图书")

    def show_books(self, books, title):
        info = ""
        for book in books:
            info += f"ID:{book.book_id} 书名:{book.title} 作者:{book.author} 出版社:{book.publisher} 可借:{book.is_available} 借阅次数:{book.borrow_count}\n"
        if not info:
            info = "无结果"
        messagebox.showinfo(title, info)

# 启动图形界面
if __name__ == "__main__":
    lib = Library(data_file="library_data.json")
    root = tk.Tk()
    gui = LibraryGUI(root, lib)
    root.mainloop()